// Simple re-export of the legacy localStorage hook so existing imports continue to work
import useLocalStorageState from "./useLocalStorageState";

export default useLocalStorageState;
